# !/usr/bin/python
# coding: utf-8

"""
@Author: Well
@Date: 2014 - 08 - 04
"""

# 1
print "Let’s learn python"
#2
string_1 = "Let’s"
string_2 = "learn"
string_3 = "python"
print string_1 + " " + string_2 + " " + string_3
#3
print "Let’s learn \"python\""
#4
string_4 = "abcdef"
print string_4[0], string_4[1:4], string_4[-3:], string_4[1::2]
print ord('s') - ord('a') + 1


import wx