# coding: utf-8
"""
@Author: niwei001
@Date: 2014 - 07 - 25
"""

import unittest
import time
import os

from selenium import webdriver
from common import login


# 用账号，登录网站，可以登录成功

class MyTestCase(unittest.TestCase):

    def setUp(self):
        time_start = time.strftime(
            "%Y:%m:%d:%H:%M:%S", time.localtime(time.time()))
        print "start test at", time_start

        # 数据初始化
        self.browser = webdriver.Chrome()
        self.browser.maximize_window()  # 浏览器初始化，并最大化
        self.base_url = 'http://dcxwwwtest.huazhu.com/'  # 主页地址
        self.user_mobile = '15618385153'  # 登录手机号
        self.password = '123321a'  # 登录密码
        self.username_username = u'倪伟'  # 登录的用户名

    def tearDown(self):
        self.browser.quit()  # 关闭浏览器
        time_end = time.strftime(
            "%Y:%m:%d:%H:%M:%S", time.localtime(time.time()))
        print "finish test at", time_end

    def test_login(self):

        self.browser.get(self.base_url)  # 打开首页
        self.browser.find_element_by_css_selector(
            'a.lnk.headNav').click()  # 跳转到登录页面
        login.login(self, self.user_mobile, self.password)  # 调用login()

        try:
            # 断言
            self.greeting_name = self.browser.find_element_by_css_selector(
                'li.login>span').text  # 登录成功：你好！xx
            # 页面右上角应该包含“登录用户名”
            self.assertTrue(self.username_username in self.greeting_name)

        finally:
            # 失败时保存截图
            file_name = os.path.basename(__file__).split('.')[0]
            png_path = os.path.dirname(
                os.path.dirname(__file__)) + '\\' + 'png'
            file_path = png_path + '\\' + file_name + '.png'
            self.browser.get_screenshot_as_file(file_path)

if __name__ == '__main__':
    unittest.main()
