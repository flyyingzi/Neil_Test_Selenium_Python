#coding: utf-8
"""
@Author: niwei001
@Date: 2014 - 07 - 25
"""
import time


def login(self, login_username, login_password):
    browser = self.browser
    # 输入会员名
    browser.find_element_by_id('txtUserMemberID').send_keys(login_username)
    # 输入密码
    browser.find_element_by_id('txtUserPwd').send_keys(login_password)
    # 点击登录按钮
    browser.find_element_by_id('ibtnlogin').click()
    # 等待2秒进行加载
    time.sleep(2)
