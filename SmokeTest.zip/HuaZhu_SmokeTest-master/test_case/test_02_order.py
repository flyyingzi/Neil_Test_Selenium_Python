#coding: utf-8
"""
@Author: niwei001
@Date: 2014 - 08 - 11
"""

import unittest
import time
from time import sleep
from datetime import datetime

from selenium import webdriver
from common import login


# 登录网站，

class MyTestCase(unittest.TestCase):

    def setUp(self):
        time_start = time.strftime("%Y:%m:%d:%H:%M:%S", time.localtime(time.time()))
        print "start test at", time_start        # 数据初始化

        self.browser = webdriver.Chrome()
        self.browser.maximize_window()  # 浏览器初始化，并最大化
        self.base_url = 'http://dcxwww.huazhu.com/'  # 主页地址
        self.user_mobile = '15618385153'  # 登录手机号
        self.password = 'ni252525'  # 登录密码
        self.username_username = u'倪伟'  # 登录的用户名

    def tearDown(self):
        self.browser.quit()  # 关闭浏览器
        time_end = time.strftime("%Y:%m:%d:%H:%M:%S", time.localtime(time.time()))
        print "finish test at", time_end

    def test_order(self):
        self.browser.get(self.base_url)  # 打开首页
        self.browser.find_element_by_css_selector('a.lnk.headNav').click()  # 跳转到登录页面
        login.login(self, self.user_mobile, self.password)  # 调用login()
        sleep(3)
        # 首页，点击“搜索”按钮
        self.browser.find_element_by_class_name('a#btn_search').click()
        sleep(3)
        # 设置搜索条件

        self.browser.find_element_by_class_name('input#cityname').send_keys(u'苏州')
        self.browser.find_element_by_class_name('input#txtCheckIn').send_keys('2014-08-11')
        self.browser.find_element_by_class_name('input#txtCheckOut').send_keys('')
        self.browser.find_element_by_class_name('a#btn_search').send_keys(u'金鸡湖')




