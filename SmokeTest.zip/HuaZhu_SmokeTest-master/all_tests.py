#coding: utf-8
"""
@Author: niwei001
@Date: 2014 - 07 - 25
"""

import unittest
import os
import time
from common import HTMLTestRunner


test_path = os.path.dirname(__file__) + '\\' + 'test_case'  # 测试脚本目录


# 创建方法：将需要测试的用例加入到测试套件中
def create_suite():
    test_suite = unittest.TestSuite()
    discover = unittest.defaultTestLoader.discover(test_path)  # 定义discover
    # discover 方法筛选出来的用例，添加到测试套件里
    for test_suit in discover:
        for test_case in test_suit:
            test_suite.addTests(test_case)
            print test_suite
    return test_suite

# 返回所有用例
all_test_names = create_suite()
print all_test_names

# 创建 report 文件
now = time.strftime('%Y-%m-%d-%H_%M_%S', time.localtime(time.time()))
file_name = os.path.dirname(__file__) + '/report/' + now + 'result.html'

fp = open(file_name, 'wb')

runner = HTMLTestRunner.HTMLTestRunner(
    stream=fp,
    title=u'测试报告',
    description=u'用例执行情况'
)

# 执行所有的测试用例
runner.run(all_test_names)